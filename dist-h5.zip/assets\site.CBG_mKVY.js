const a="SAP 顾问需求广场",s="待填写",o="https://beian.miit.gov.cn/",t="your@email.com";export{t as C,s as I,a as S,o as a};
